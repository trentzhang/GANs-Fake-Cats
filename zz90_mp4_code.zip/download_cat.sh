#!/usr/bin/env bash

# download 
wget https://uofi.box.com/shared/static/pq6nt3o77vujmxhpkb0ixssa8xjvnrpu.zip
unzip pq6nt3o77vujmxhpkb0ixssa8xjvnrpu.zip
rm pq6nt3o77vujmxhpkb0ixssa8xjvnrpu.zip
